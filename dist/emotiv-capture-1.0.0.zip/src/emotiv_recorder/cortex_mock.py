import threading
import time
import random
from typing import Callable, List, Optional
from emotiv_data import EmotivData

class CortexMockClient:
 
    def __init__(self, client_id: str, client_secret: str):
        self.listeners: List[Callable[[EmotivData], None]] = []
        self.should_run = False
        self.thread: Optional[threading.Thread] = None
        self.is_connected = False

    def add_listener(self, listener: Callable[[EmotivData], None]):
        if listener not in self.listeners:
            self.listeners.append(listener)

    def connect(self):
        print("[Mock Cortex] Iniciando conexión simulada...")
        self.should_run = True
        self.is_connected = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def disconnect(self):
        print("[Mock Cortex] Desconectando...")
        self.should_run = False
        self.is_connected = False
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=1.0)
        print("[Mock Cortex] Desconectado.")

    def _loop(self):
        print("[Mock Cortex] Generando datos de prueba...")
        while self.should_run:
            time.sleep(0.25) 
            
            data = EmotivData()
            data.timestamp = time.time() * 1000
            
            data.metrics.stress = random.uniform(0.1, 0.5)
            data.metrics.engagement = random.uniform(0.5, 0.9)
            data.metrics.interest = random.uniform(0.3, 0.8)
            data.metrics.excitement = random.uniform(0.0, 0.4)
            data.metrics.focus = random.uniform(0.4, 0.9)
            data.metrics.relaxation = random.uniform(0.2, 0.6)

            data.power.theta = random.uniform(5, 15)
            data.power.alpha = random.uniform(8, 12)
            data.power.low_beta = random.uniform(12, 20)
            data.power.high_beta = random.uniform(18, 30)
            data.power.gamma = random.uniform(25, 45)

            data.battery_level = 100
            data.headset_id = "MOCK-HEADSET-01"

            for listener in self.listeners:
                listener(data)