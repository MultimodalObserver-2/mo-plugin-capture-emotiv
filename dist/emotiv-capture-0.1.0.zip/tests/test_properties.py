import sys
import os
import types
import unittest

class MockProperties:
    def __init__(self):
        self._fields = {}
        self._defaults = {}

    def add_text(self, key, label=None):
        self._fields[key] = {'type': 'text', 'label': label}

    def add_bool(self, key, label=None):
        self._fields[key] = {'type': 'bool', 'label': label}

    def set_default(self, key, value):
        self._defaults[key] = value


mock_mo = types.ModuleType('mo')
mock_mo.Properties = MockProperties
mock_mo.translate = lambda k: k
sys.modules['mo'] = mock_mo

SRC = os.path.join(os.path.dirname(__file__), '..', 'src', 'emotiv_recorder')
if SRC not in sys.path:
    sys.path.insert(0, SRC)

for _key in list(sys.modules.keys()):
    if 'properties' in _key and 'emotiv' in _key.lower():
        del sys.modules[_key]
if 'properties' in sys.modules and hasattr(sys.modules['properties'], '_fields'):
    del sys.modules['properties']

import importlib
import properties as props_mod


class TestPropertiesFields(unittest.TestCase):

    def test_has_client_id(self):
        self.assertIn('client_id', props_mod.properties._fields)

    def test_has_client_secret(self):
        self.assertIn('client_secret', props_mod.properties._fields)

    def test_has_simulate_device(self):
        self.assertIn('simulate_device', props_mod.properties._fields)

    def test_client_id_is_text(self):
        self.assertEqual(props_mod.properties._fields['client_id']['type'], 'text')

    def test_client_secret_is_text(self):
        self.assertEqual(props_mod.properties._fields['client_secret']['type'], 'text')

    def test_simulate_device_is_bool(self):
        self.assertEqual(props_mod.properties._fields['simulate_device']['type'], 'bool')


class TestPropertiesDefaults(unittest.TestCase):

    def test_client_id_is_empty_string(self):
        self.assertEqual(props_mod.properties._defaults['client_id'], '')

    def test_client_secret_default_is_empty_string(self):
        self.assertEqual(props_mod.properties._defaults['client_secret'], '')

    def test_simulate_device_default_is_false(self):
        self.assertFalse(props_mod.properties._defaults['simulate_device'])


if __name__ == '__main__':
    unittest.main()
